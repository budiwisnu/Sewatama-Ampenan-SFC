package com.sewatama.ampenansfc.util

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.sewatama.ampenansfc.data.DailySfcEntity
import com.sewatama.ampenansfc.domain.SfcCalculationEngine
import java.io.File

object CsvExportHelper {

    fun exportAndShareCsv(
        context: Context,
        records: List<DailySfcEntity>,
        startDate: String,
        endDate: String
    ) {
        val csvHeader = listOf(
            "Tanggal",
            "Jam",
            "Nama Operator",
            "kWh Blok 1 Kemarin",
            "kWh Blok 1 Hari Ini",
            "kWh Blok 2 Kemarin",
            "kWh Blok 2 Hari Ini",
            "Total Produksi Listrik (kWh)",
            "Top-Up Tangki Penuh (14000L)",
            "Level Tangki 1 Aktual (L)",
            "Level Tangki 2 Aktual (L)",
            "Flow Meter Kemarin (L)",
            "Flow Meter Hari Ini (L)",
            "Total Pemakaian BBM (Liter)",
            "SFC (L/kWh)",
            "Tier SFC",
            "Warna Indikator",
            "Indikasi Operasional",
            "Keterangan Kendala"
        ).joinToString(",")

        val csvBody = records.joinToString("\n") { r ->
            val tier = SfcCalculationEngine.evaluateTier(r.sfcValue)
            listOf(
                r.recordDate,
                r.recordTime,
                "\"" + r.operatorName + "\"",
                r.prevKwhBlok1,
                r.kwhBlok1Today,
                r.prevKwhBlok2,
                r.kwhBlok2Today,
                r.totalKwh,
                if (r.isTankTopUpFull) "YA" else "TIDAK",
                r.tank1LevelActual,
                r.tank2LevelActual,
                r.prevFlowMeterBbm,
                r.flowMeterBbmToday,
                r.totalBbmLiter,
                r.sfcFormatted,
                "Tier " + tier.tierNumber,
                tier.colorName,
                "\"" + tier.indication + "\"",
                "\"" + r.constraintNotes.replace("\"", "'") + "\""
            ).joinToString(",")
        }

        val fileName = "Laporan_SFC_Ampenan_" + startDate + "_sd_" + endDate + ".csv"
        val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(exportDir, fileName)
        file.writeText(csvHeader + "\n" + csvBody)

        val uri = FileProvider.getUriForFile(
            context,
            context.packageName + ".fileprovider",
            file
        )

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_SUBJECT, "Laporan SFC PLTD Sewatama Ampenan (" + startDate + " s/d " + endDate + ")")
            putExtra(Intent.EXTRA_TEXT, "Terlampir laporan operasional harian dan evaluasi SFC PLTD Ampenan.")
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        context.startActivity(Intent.createChooser(shareIntent, "Bagikan Laporan CSV via WhatsApp / Email"))
    }
}