package com.sewatama.ampenansfc.domain

import androidx.compose.ui.graphics.Color
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Locale

enum class SfcTier(
    val tierNumber: Int,
    val rangeDescription: String,
    val colorName: String,
    val textColor: Color,
    val indication: String
) {
    TIER_1(
        tierNumber = 1,
        rangeDescription = "SFC < 0.2750",
        colorName = "Merah",
        textColor = Color(0xFFEF4444),
        indication = "Under-reading / Kebocoran Return BBM"
    ),
    TIER_2(
        tierNumber = 2,
        rangeDescription = "0.2750 <= SFC < 0.2800",
        colorName = "Kuning",
        textColor = Color(0xFFF59E0B),
        indication = "Batas Bawah / Perlu Pengawasan"
    ),
    TIER_3(
        tierNumber = 3,
        rangeDescription = "0.2800 <= SFC <= 0.2840",
        colorName = "Hijau",
        textColor = Color(0xFF10B981),
        indication = "Optimal / Normal"
    ),
    TIER_4(
        tierNumber = 4,
        rangeDescription = "0.2840 < SFC < 0.2870",
        colorName = "Kuning",
        textColor = Color(0xFFF59E0B),
        indication = "Batas Atas / Indikasi Inefisiensi"
    ),
    TIER_5(
        tierNumber = 5,
        rangeDescription = "SFC >= 0.2870",
        colorName = "Merah",
        textColor = Color(0xFFEF4444),
        indication = "Pemborosan / Over-consumption"
    )
}

data class SfcCalculationResult(
    val totalKwh: Double,
    val totalBbmLiter: Double,
    val sfcValue: Double,
    val sfcFormatted: String,
    val tier: SfcTier
)

object SfcCalculationEngine {

    const val STANDBY_CAPACITY_LITERS = 14000.0

    private val BOUNDARY_TIER_1 = BigDecimal("0.2750")
    private val BOUNDARY_TIER_2 = BigDecimal("0.2800")
    private val BOUNDARY_TIER_3_MAX = BigDecimal("0.2840")
    private val BOUNDARY_TIER_4_MAX = BigDecimal("0.2870")

    fun calculateDailySfc(
        kwhBlok1Today: Double,
        kwhBlok1Yesterday: Double,
        kwhBlok2Today: Double,
        kwhBlok2Yesterday: Double,
        isTankTopUpFull: Boolean,
        tank1LevelActual: Double,
        tank2LevelActual: Double,
        flowMeterToday: Double,
        flowMeterYesterday: Double
    ): SfcCalculationResult {
        val deltaBlok1 = kwhBlok1Today - kwhBlok1Yesterday
        val deltaBlok2 = kwhBlok2Today - kwhBlok2Yesterday
        val totalKwh = deltaBlok1 + deltaBlok2

        val flowDiff = flowMeterToday - flowMeterYesterday
        val totalBbmLiter = if (isTankTopUpFull) {
            flowDiff
        } else {
            flowDiff + (STANDBY_CAPACITY_LITERS - tank1LevelActual) + (STANDBY_CAPACITY_LITERS - tank2LevelActual)
        }

        require(totalKwh > 0.0) { "Total Produksi Listrik (kWh) harus lebih besar dari 0." }
        require(totalBbmLiter >= 0.0) { "Total Pemakaian BBM (Liter) tidak valid." }

        val sfcBigDecimal = BigDecimal.valueOf(totalBbmLiter)
            .divide(BigDecimal.valueOf(totalKwh), 4, RoundingMode.HALF_UP)

        val sfcDouble = sfcBigDecimal.toDouble()
        val sfcFormatted = String.format(Locale.US, "%.4f", sfcBigDecimal)
        val tier = evaluateTier(sfcBigDecimal)

        return SfcCalculationResult(
            totalKwh = totalKwh,
            totalBbmLiter = totalBbmLiter,
            sfcValue = sfcDouble,
            sfcFormatted = sfcFormatted,
            tier = tier
        )
    }

    fun evaluateTier(sfcValue: Double): SfcTier {
        val bd = BigDecimal.valueOf(sfcValue).setScale(4, RoundingMode.HALF_UP)
        return evaluateTier(bd)
    }

    fun evaluateTier(sfcBd: BigDecimal): SfcTier {
        val normalized = sfcBd.setScale(4, RoundingMode.HALF_UP)
        return when {
            normalized < BOUNDARY_TIER_1 -> SfcTier.TIER_1
            normalized >= BOUNDARY_TIER_1 && normalized < BOUNDARY_TIER_2 -> SfcTier.TIER_2
            normalized >= BOUNDARY_TIER_2 && normalized <= BOUNDARY_TIER_3_MAX -> SfcTier.TIER_3
            normalized > BOUNDARY_TIER_3_MAX && normalized < BOUNDARY_TIER_4_MAX -> SfcTier.TIER_4
            else -> SfcTier.TIER_5
        }
    }

    fun formatFourDecimals(value: Double): String {
        val bd = BigDecimal.valueOf(value).setScale(4, RoundingMode.HALF_UP)
        return String.format(Locale.US, "%.4f", bd)
    }
}