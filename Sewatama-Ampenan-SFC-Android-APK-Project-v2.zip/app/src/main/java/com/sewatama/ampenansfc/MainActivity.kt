package com.sewatama.ampenansfc

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sewatama.ampenansfc.data.DailySfcEntity
import com.sewatama.ampenansfc.domain.SfcCalculationEngine
import com.sewatama.ampenansfc.ui.SfcViewModel
import com.sewatama.ampenansfc.util.CsvExportHelper
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    private val viewModel: SfcViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFFF59E0B),
                    background = Color(0xFF090D16),
                    surface = Color(0xFF111827)
                )
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    SewatamaAmpenanApp(viewModel = viewModel)
                }
            }
        }
    }
}

enum class AppScreen(val title: String) {
    LOGIN("Login"),
    MASTER_HARI_0("Master Hari-0"),
    FORM_UTAMA("Input Jam 10:00"),
    LAPORAN("Laporan & CSV")
}

@Composable
fun SewatamaAmpenanApp(viewModel: SfcViewModel) {
    val isAuthenticated by viewModel.isAuthenticated.collectAsState()
    val masterConfig by viewModel.masterConfig.collectAsState()
    val allRecords by viewModel.allRecords.collectAsState()

    var currentScreen by remember { mutableStateOf(AppScreen.LOGIN) }

    LaunchedEffect(isAuthenticated) {
        if (isAuthenticated) {
            currentScreen = if (!masterConfig.isConfigured && allRecords.isEmpty()) {
                AppScreen.MASTER_HARI_0
            } else {
                AppScreen.FORM_UTAMA
            }
        } else {
            currentScreen = AppScreen.LOGIN
        }
    }

    Scaffold(
        bottomBar = {
            if (isAuthenticated) {
                NavigationBar(containerColor = Color(0xFF111827)) {
                    listOf(
                        AppScreen.FORM_UTAMA,
                        AppScreen.MASTER_HARI_0,
                        AppScreen.LAPORAN
                    ).forEach { screen ->
                        NavigationBarItem(
                            selected = currentScreen == screen,
                            onClick = { currentScreen = screen },
                            label = { Text(screen.title) },
                            icon = {}
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when (currentScreen) {
                AppScreen.LOGIN -> LoginScreen(
                    onLoginSuccess = { username, password ->
                        viewModel.authenticate(username, password)
                    }
                )
                AppScreen.MASTER_HARI_0 -> MasterDayZeroScreen(
                    initialFlow = masterConfig.initialFlowMeterBbm,
                    initialKwh1 = masterConfig.initialKwhBlok1,
                    initialKwh2 = masterConfig.initialKwhBlok2,
                    onSave = { flow, kwh1, kwh2 ->
                        viewModel.saveMasterDayZero(flow, kwh1, kwh2)
                        currentScreen = AppScreen.FORM_UTAMA
                    }
                )
                AppScreen.FORM_UTAMA -> MainOperationalFormScreen(
                    viewModel = viewModel,
                    records = allRecords,
                    onSaved = { currentScreen = AppScreen.LAPORAN }
                )
                AppScreen.LAPORAN -> ReportAndExportScreen(
                    viewModel = viewModel,
                    records = allRecords
                )
            }
        }
    }
}