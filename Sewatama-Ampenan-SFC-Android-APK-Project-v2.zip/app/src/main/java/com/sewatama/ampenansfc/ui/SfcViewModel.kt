package com.sewatama.ampenansfc.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sewatama.ampenansfc.data.DailySfcEntity
import com.sewatama.ampenansfc.data.MasterDayZeroConfig
import com.sewatama.ampenansfc.data.MasterPreferencesRepository
import com.sewatama.ampenansfc.data.SfcAppDatabase
import com.sewatama.ampenansfc.domain.SfcCalculationEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.math.RoundingMode

class SfcViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = SfcAppDatabase.getInstance(application).sfcRecordDao()
    private val masterPrefs = MasterPreferencesRepository(application)

    private val _isAuthenticated = MutableStateFlow(false)
    val isAuthenticated: StateFlow<Boolean> = _isAuthenticated.asStateFlow()

    private val _masterConfig = MutableStateFlow(masterPrefs.getMasterDayZero())
    val masterConfig: StateFlow<MasterDayZeroConfig> = _masterConfig.asStateFlow()

    val allRecords: StateFlow<List<DailySfcEntity>> = dao.getAllRecordsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun authenticate(username: String, password: String): Boolean {
        val valid = username.trim() == "ampenan" && password == "sewatama"
        _isAuthenticated.value = valid
        return valid
    }

    fun saveMasterDayZero(flowMeterBbm: Double, kwhBlok1: Double, kwhBlok2: Double) {
        masterPrefs.saveMasterDayZero(flowMeterBbm, kwhBlok1, kwhBlok2)
        _masterConfig.value = masterPrefs.getMasterDayZero()
    }

    fun getBaselineYesterday(records: List<DailySfcEntity>, master: MasterDayZeroConfig): Triple<Double, Double, Double> {
        val latest = records.firstOrNull()
        return if (latest != null) {
            Triple(latest.kwhBlok1Today, latest.kwhBlok2Today, latest.flowMeterBbmToday)
        } else {
            Triple(master.initialKwhBlok1, master.initialKwhBlok2, master.initialFlowMeterBbm)
        }
    }

    fun submitDailyRecord(
        date: String,
        time: String,
        operatorName: String,
        kwhBlok1Today: Double,
        kwhBlok2Today: Double,
        isTankTopUpFull: Boolean,
        tank1ActualInput: Double,
        tank2ActualInput: Double,
        constraintNotes: String,
        flowMeterToday: Double,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            try {
                val (prevKwh1, prevKwh2, prevFlow) = getBaselineYesterday(allRecords.value, _masterConfig.value)
                val tank1Actual = if (isTankTopUpFull) 14000.0 else tank1ActualInput
                val tank2Actual = if (isTankTopUpFull) 14000.0 else tank2ActualInput

                val calcResult = SfcCalculationEngine.calculateDailySfc(
                    kwhBlok1Today = kwhBlok1Today,
                    kwhBlok1Yesterday = prevKwh1,
                    kwhBlok2Today = kwhBlok2Today,
                    kwhBlok2Yesterday = prevKwh2,
                    isTankTopUpFull = isTankTopUpFull,
                    tank1LevelActual = tank1Actual,
                    tank2LevelActual = tank2Actual,
                    flowMeterToday = flowMeterToday,
                    flowMeterYesterday = prevFlow
                )

                val entity = DailySfcEntity(
                    recordDate = date,
                    recordTime = time,
                    operatorName = operatorName,
                    prevKwhBlok1 = prevKwh1,
                    prevKwhBlok2 = prevKwh2,
                    prevFlowMeterBbm = prevFlow,
                    kwhBlok1Today = kwhBlok1Today,
                    kwhBlok2Today = kwhBlok2Today,
                    isTankTopUpFull = isTankTopUpFull,
                    tank1LevelActual = tank1Actual,
                    tank2LevelActual = tank2Actual,
                    constraintNotes = if (isTankTopUpFull) "" else constraintNotes,
                    flowMeterBbmToday = flowMeterToday,
                    totalKwh = calcResult.totalKwh,
                    totalBbmLiter = calcResult.totalBbmLiter,
                    sfcValue = calcResult.sfcValue,
                    sfcFormatted = calcResult.sfcFormatted
                )

                dao.insertRecord(entity)
                onSuccess()
            } catch (e: Exception) {
                onError(e.message ?: "Gagal menyimpan data operasional.")
            }
        }
    }

    fun calculateRunningMonthAverage(records: List<DailySfcEntity>): Double {
        if (records.isEmpty()) return 0.0
        val latestDate = records.maxOf { it.recordDate }
        val yearMonth = latestDate.take(7)
        val monthRecords = records.filter { it.recordDate.startsWith(yearMonth) && it.recordDate <= latestDate }
        if (monthRecords.isEmpty()) return 0.0

        val sum = monthRecords.fold(BigDecimal.ZERO) { acc, item ->
            acc.add(BigDecimal.valueOf(item.sfcValue))
        }
        return sum.divide(BigDecimal.valueOf(monthRecords.size.toLong()), 4, RoundingMode.HALF_UP).toDouble()
    }
}