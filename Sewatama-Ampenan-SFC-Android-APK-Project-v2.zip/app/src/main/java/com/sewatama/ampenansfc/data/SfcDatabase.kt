package com.sewatama.ampenansfc.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "daily_sfc_records")
data class DailySfcEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val recordDate: String,
    val recordTime: String,
    val operatorName: String,
    val prevKwhBlok1: Double,
    val prevKwhBlok2: Double,
    val prevFlowMeterBbm: Double,
    val kwhBlok1Today: Double,
    val kwhBlok2Today: Double,
    val isTankTopUpFull: Boolean,
    val tank1LevelActual: Double,
    val tank2LevelActual: Double,
    val constraintNotes: String,
    val flowMeterBbmToday: Double,
    val totalKwh: Double,
    val totalBbmLiter: Double,
    val sfcValue: Double,
    val sfcFormatted: String
)

@Dao
interface SfcRecordDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: DailySfcEntity)

    @Query("SELECT * FROM daily_sfc_records ORDER BY recordDate DESC, id DESC")
    fun getAllRecordsFlow(): Flow<List<DailySfcEntity>>
}

@Database(entities = [DailySfcEntity::class], version = 1, exportSchema = false)
abstract class SfcAppDatabase : RoomDatabase() {
    abstract fun sfcRecordDao(): SfcRecordDao

    companion object {
        @Volatile
        private var INSTANCE: SfcAppDatabase? = null

        fun getInstance(context: Context): SfcAppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SfcAppDatabase::class.java,
                    "sewatama_ampenan_sfc.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}

data class MasterDayZeroConfig(
    val initialFlowMeterBbm: Double,
    val initialKwhBlok1: Double,
    val initialKwhBlok2: Double,
    val isConfigured: Boolean
)

class MasterPreferencesRepository(context: Context) {
    private val prefs = context.getSharedPreferences("master_hari_0_prefs", Context.MODE_PRIVATE)

    fun saveMasterDayZero(flowMeter: Double, kwhBlok1: Double, kwhBlok2: Double) {
        prefs.edit()
            .putString("initial_flow_meter_bbm", flowMeter.toString())
            .putString("initial_kwh_blok_1", kwhBlok1.toString())
            .putString("initial_kwh_blok_2", kwhBlok2.toString())
            .putBoolean("is_configured", true)
            .apply()
    }

    fun getMasterDayZero(): MasterDayZeroConfig {
        val flow = prefs.getString("initial_flow_meter_bbm", "1250000.0")?.toDoubleOrNull() ?: 1250000.0
        val kwh1 = prefs.getString("initial_kwh_blok_1", "4520000.0")?.toDoubleOrNull() ?: 4520000.0
        val kwh2 = prefs.getString("initial_kwh_blok_2", "3890000.0")?.toDoubleOrNull() ?: 3890000.0
        val configured = prefs.getBoolean("is_configured", false)
        return MasterDayZeroConfig(flow, kwh1, kwh2, configured)
    }
}