# Panduan Perbaikan Error GitHub Actions & Build APK (Versi 2.0 — AGP 8.7.3 + Kotlin 2.0.21 + Gradle 8.10.2)

## Mengapa Sebelumnya Muncul Error "Task 'assembleDebug' not found in root project 'SewatamaAmpenanSFC'"?
Saat mengunggah file ke GitHub melalui browser HP Android, pemilih file Android sering kali tidak mengikutsertakan subfolder `app/` atau menimpa `build.gradle.kts` root dengan `app/build.gradle.kts`, sehingga subproject `:app` dianggap kosong oleh Gradle dan task `assembleDebug` tidak ditemukan.

## Solusi Permanen (Sudah Diperbaiki di Versi 2.0 Ini)
1. **Self-Healing Workflow (`.github/workflows/build-apk.yml`)**:
   Workflow GitHub Actions kini secara otomatis **memverifikasi dan membangun ulang seluruh struktur folder `app/src/main/...` beserta `app/build.gradle.kts`** sebelum menjalankan `gradle :app:assembleDebug --no-daemon`.
   Bahkan jika Anda **HANYA** menyalin isi file `build-apk.yml` ke `.github/workflows/build-apk.yml` di repositori GitHub Anda, GitHub Actions akan otomatis men-generate seluruh kode sumber Kotlin, Manifest, dan Gradle, lalu menghasilkan file **`Sewatama-Ampenan-SFC.apk`**!
2. **Sistem Build Android Terbaru (Bebas Warning Deprecated Gradle 9.0)**:
   - **Gradle**: `8.10.2` dengan `gradle/actions/setup-gradle@v4`
   - **Android Gradle Plugin (AGP)**: `8.7.3` (Compile SDK 35, Target SDK 35, Min SDK 30)
   - **Kotlin**: `2.0.21` + Plugin Resmi `org.jetbrains.kotlin.plugin.compose`
   - **KSP**: `2.0.21-1.0.28` + **Room Database**: `2.6.1`
