#!/usr/bin/env bash
echo "Memulai proses kompilasi APK Sewatama Ampenan SFC..."
gradle :app:assembleDebug --no-daemon
echo "File APK berhasil dibuat di: app/build/outputs/apk/debug/app-debug.apk"
